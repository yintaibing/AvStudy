#!/bin/bash
NDK=/home/ytb/Downloads/android-ndk-r21d
API=19
ARCH=arm
PLATFORM=armv7a
HOST=arm-linux-android
TARGET=$PLATFORM-linux-androideabi
TOOLCHAIN=$NDK/toolchains/llvm/prebuilt/linux-x86_64
SYSROOT=$NDK/sysroot
PREFIX=./android/$PLATFORM

CFLAGS="-D__ANDROID_API__=$API -g -DANDROID -ffunction-sections -funwind-tables -fstack-protector-strong -no-canonical-prefixes -march=armv7-a -mfloat-abi=softfp -mfpu=vfpv3-d16 -mthumb -Wa,--noexecstack -Wformat -Werror=format-security  -O0 -fPIC"
#--disable-cli 不需要命令行工具
#--enable-static 静态库
#和ffmpeg差不多
build_one()
{
./configure \
--prefix=$PREFIX \
--host=$HOST \
--disable-cli \
--disable-asm \
--enable-static \
--enable-shared \
--enable-pic \
#--cross-prefix=$TOOLCHAIN/bin/arm-linux-androideabi- \
#--sysroot=$NDK/platforms/android-$API/arch-arm \
--extra-cflags="$CFLAGS"

make clean
make -j8
make install
}

export AR=$TOOLCHAIN/bin/arm-linux-androideabi-ar
export AS=$TOOLCHAIN/bin/arm-linux-androideabi-as
export LD=$TOOLCHAIN/bin/arm-linux-androideabi-ld
export RANLIB=$TOOLCHAIN/bin/arm-linux-androideabi-ranlib
export STRIP=$TOOLCHAIN/bin/arm-linux-androideabi-strip
export CC=$TOOLCHAIN/bin/$PLATFORM-linux-androideabi$API-clang
export CXX=$TOOLCHAIN/bin/$PLATFORM-linux-androideabi$API-clang++

build_one
