#!/bin/bash
export TMPDIR=`dirname $0`/tmpdir
NDK=D:/android-ndk-r20
API=19
# arm aarch64 i686 x86_64
ARCH=arm
# armv7a aarch64 i686 x86_64
PLATFORM=armv7a
TARGET=$PLATFORM-linux-androideabi
TOOLCHAIN=$NDK/toolchains/llvm/prebuilt/windows-x86_64/bin
SYSROOT=$NDK/sysroot
PREFIX=`dirname $0`/android/$PLATFORM

FDKAAC_DIR=D:/avstudy/fdk-aac-2.0.0/android/$PLATFORM
MP3LAME_DIR=D:/avstudy/lame-3.100/android/$PLATFORM
X264_DIR=D:/avstudy/x264-master/android/$PLATFORM

CFLAG="-I$FDKAAC_DIR/include -I$MP3LAME_DIR/include -I$X264_DIR/include -D__ANDROID_API__=$API -U_FILE_OFFSET_BITS -DBIONIC_IOCTL_NO_SIGNEDNESS_OVERLOAD -Os -fPIC -DANDROID -D__thumb__ -mthumb -Wfatal-errors -Wno-deprecated -mfloat-abi=softfp -marm"
LDFLAGS="-L$FDKAAC_DIR/lib -L$MP3LAME_DIR/lib -L$X264_DIR/lib -marm"
mkdir -p $TMPDIR
build_one()
{
./configure \
--ln_s="cp -rf" \
--prefix=$PREFIX \
--cc=$TOOLCHAIN/$TARGET$API-clang \
--cxx=$TOOLCHAIN/$TARGET$API-clang++ \
--ld=$TOOLCHAIN/$TARGET$API-clang \
--target-os=android \
--arch=$ARCH \
--cpu=$PLATFORM \
--cross-prefix=$TOOLCHAIN/$ARCH-linux-androideabi- \
--sysroot=$SYSROOT \
--disable-asm \
--enable-cross-compile \
--enable-shared \
--disable-static \
--enable-runtime-cpudetect \
--disable-doc \
--disable-ffmpeg \
--disable-ffplay \
--disable-ffprobe \
--disable-doc \
--disable-symver \
--enable-small \
--enable-gpl --enable-nonfree --enable-version3 --disable-iconv \
--enable-jni \
--enable-mediacodec \
# enable fdk_aac mp3lame x264
--enable-libfdk_aac \
--enable-libmp3lame \
--enable-libx264 \
# decoders
--disable-decoders \
--enable-decoder=vp9 \
--enable-decoder=h264 \
--enable-decoder=mpeg4 \
--enable-decoder=aac \
--enable-decoder=libfdk_aac \
# encoders
--disable-encoders \
--enable-encoder=vp9_vaapi \
--enable-encoder=h264_nvenc \
--enable-encoder=h264_v4l2m2m \
--enable-encoder=hevc_nvenc \
--enable-encoder=libfdk_aac \
--enable-encoder=libmp3lame \
--enable-encoder=libx264 \
# demuxers
--disable-demuxers \
--enable-demuxer=rtsp \
--enable-demuxer=rtp \
--enable-demuxer=flv \
--enable-demuxer=h264 \
# muxers
--disable-muxers \
--enable-muxer=rtsp \
--enable-muxer=rtp \
--enable-muxer=flv \
--enable-muxer=h264 \
# parsers
--disable-parsers \
--enable-parser=mpeg4video \
--enable-parser=aac \
--enable-parser=h264 \
--enable-parser=vp9 \
# protocols
--disable-protocols \
--enable-protocol=http \
--enable-protocol=https \
--enable-protocol=rtmp \
--enable-protocol=rtp \
--enable-protocol=tcp \
--enable-protocol=udp \
--disable-bsfs \
--disable-indevs --enable-indev=v4l2 \
--disable-outdevs \
--disable-filters \
--disable-postproc \
--extra-cflags="$CFLAG" \
--extra-ldflags="$LDFLAGS"
}
build_one
make clean
make -j4
make install